<?php

namespace Zinkil\pc\commands;

use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;
use Zinkil\pc\forms\{SimpleForm, CustomForm};
use Zinkil\pc\Core;
use Zinkil\pc\Utils;

class RankCommand extends PluginCommand{
	
	private $plugin;
	
	public $targetPlayer=[];
	
	public function __construct(Core $plugin){
		parent::__construct("rank", $plugin);
		$this->plugin=$plugin;
		$this->setDescription("§bGive a player a rank");
		$this->setPermission("pc.command.rank");
	}
	public function execute(CommandSender $player, string $commandLabel, array $args){
		if(!$player->hasPermission("pc.command.rank")){
			$player->sendMessage("§cYou cannot execute this command.");
		}else{
			if($player instanceof Player){
				$this->rankMainForm($player);
				return;
			}
		}
	}
	public function rankMainForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "list":
				$this->rankListForm($player);
				break;
				case "set":
				$this->playerListForm($player);
				break;
			}
		});
		$rank=$this->plugin->getDatabaseHandler()->getRank($player->getName());
		$form->setTitle("§l§cRank");
		$form->addButton("Available Ranks", -1, "", "list");
		$form->addButton("Set a Rank", -1, "", "set");
		$player->sendForm($form);
	}
	public function rankListForm(Player $player):void{;
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "player":
				$rank="Player";
				$this->rankInfoForm($player, $rank);
				break;
				case "voter":
				$rank="Voter";
				$this->rankInfoForm($player, $rank);
				break;
				case "elite":
				$rank="Elite";
				$this->rankInfoForm($player, $rank);
				break;
				case "premium":
				$rank="Premium";
				$this->rankInfoForm($player, $rank);
				break;
				case "booster":
				$rank="Booster";
				$this->rankInfoForm($player, $rank);
				break;
				case "youtube":
				$rank="YouTube";
				$this->rankInfoForm($player, $rank);
				break;
				case "famous":
				$rank="Famous";
				$this->rankInfoForm($player, $rank);
				break;
				case "trainee":
				$rank="Trainee";
				$this->rankInfoForm($player, $rank);
				break;
				case "helper":
				$rank="Helper";
				$this->rankInfoForm($player, $rank);
				break;
				case "builder":
				$rank="Builder";
				$this->rankInfoForm($player, $rank);
				break;
				case "mod":
				$rank="Mod";
				$this->rankInfoForm($player, $rank);
				break;
				case "headmod":
				$rank="HeadMod";
				$this->rankInfoForm($player, $rank);
				break;
				case "admin":
				$rank="Admin";
				$this->rankInfoForm($player, $rank);
				break;
				case "manager":
				$rank="Manager";
				$this->rankInfoForm($player, $rank);
				break;
				case "owner":
				$rank="Owner";
				$this->rankInfoForm($player, $rank);
				break;
				case "exit":
				$this->rankMainForm($player);
				break;
			}
		});
		$form->setTitle("§l§cAvailable Ranks");
		//$form->addButton("Player\n(".$this->plugin->getDatabaseHandler()->countWithRank("Player")." total)", -1, "", "player");
		$form->addButton("Voter\n(".$this->plugin->getDatabaseHandler()->countWithRank("Voter")." total)", -1, "", "voter");
		$form->addButton("Elite\n(".$this->plugin->getDatabaseHandler()->countWithRank("Elite")." total)", -1, "", "elite");
		$form->addButton("Premium\n(".$this->plugin->getDatabaseHandler()->countWithRank("Premium")." total)", -1, "", "premium");
		$form->addButton("Booster\n(".$this->plugin->getDatabaseHandler()->countWithRank("Booster")." total)", -1, "", "booster");
		$form->addButton("YouTube\n(".$this->plugin->getDatabaseHandler()->countWithRank("YouTube")." total)", -1, "", "youtube");
		$form->addButton("Famous\n(".$this->plugin->getDatabaseHandler()->countWithRank("Famous")." total)", -1, "", "famous");
		$form->addButton("Trainee\n(".$this->plugin->getDatabaseHandler()->countWithRank("Trainee")." total)", -1, "", "trainee");
		$form->addButton("Helper\n(".$this->plugin->getDatabaseHandler()->countWithRank("Helper")." total)", -1, "", "helper");
		$form->addButton("Builder\n(".$this->plugin->getDatabaseHandler()->countWithRank("Builder")." total)", -1, "", "builder");
		$form->addButton("Mod\n(".$this->plugin->getDatabaseHandler()->countWithRank("Mod")." total)", -1, "", "mod");
		$form->addButton("HeadMod\n(".$this->plugin->getDatabaseHandler()->countWithRank("HeadMod")." total)", -1, "", "headmod");
		$form->addButton("Admin\n(".$this->plugin->getDatabaseHandler()->countWithRank("Admin")." total)", -1, "", "admin");
		$form->addButton("Manager\n(".$this->plugin->getDatabaseHandler()->countWithRank("Manager")." total)", -1, "", "manager");
		$form->addButton("Owner\n(".$this->plugin->getDatabaseHandler()->countWithRank("Owner")." total)", -1, "", "owner");
		$form->addButton("« Back", -1, "", "exit");
		$player->sendForm($form);
	}
	public function playerListForm(Player $player):void{
		$form=new SimpleForm(function(Player $player, $data=null):void{
			switch($data){
				case "exit":
				$this->playerListForm($player);
				break;
				case "perm":
				$this->rankSetPermForm($player);
				break;
				case "temp":
				//$this->rankSetTempForm($player);
				$player->sendMessage("§b§lXAGE §8»§r§c Temp ranks are disabled.");
				break;
			}
		});
		$form->setTitle("§l§cSelect a Rank Variation");
		$form->addButton("Permanent", -1, "", "perm");
		$form->addButton("Temporary", -1, "", "temp");
		$form->addButton("« Back", -1, "", "exit");
		$player->sendForm($form);
	}
	public function rankSetPermForm(Player $player):void{
	  $list = [];
    foreach($this->plugin->getServer()->getOnlinePlayers() as $p){
      $list[] = $p->getName();
    }
    $this->targetPlayer[$player->getName()] = $list;
		$form=new CustomForm(function(Player $player, array $data=null):void{
			switch($data){
				case 0:
				return;
				break;
			}
			$target=$this->targetPlayer[$player->getName()][$data[0]];
			switch($data[1]){
				case 0:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Player";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 1:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Voter";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 2:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Elite";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 3:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Premium";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 4:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Booster";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 5:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="YouTube";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 6:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Famous";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 7:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Builder";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 8:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Trainee";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 9:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Helper";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
				$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 10:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Mod";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 11:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="HeadMod";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 12:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Admin";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 13:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Manager";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case 14:
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Owner";
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					$this->plugin->getDatabaseHandler()->setRank($target, $newrank);
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank.".");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank.".");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("rankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
			}
			unset($this->targetPlayer[$player->getName()]);
		});
		$targe=$this->targetPlayer[$player->getName()];
		$rank = $this->plugin->getDatabaseHandler()->getRank($player);
		$ranks=["Player", "Voter", "Elite", "Premium", "Booster", "YouTube", "Famous", "Builder", "Trainee", "Helper", "Mod", "HeadMod", "Admin", "Manager", "Owner"];
		$adminranks=["Player", "Voter", "Elite", "Premium", "Booster", "YouTube", "Famous", "Builder"];
		$form->setTitle("§l§cPerm Rank");
		$form->addDropdown("Select a player", $this->targetPlayer[$player->getName()]);
		if($player->isOp() or $rank == "Owner"){
		    $form->addDropdown("Choose a rank", $ranks, 0);
		}
		if(!$player->isOp() and $rank == "Admin"){
		    $form->addDropdown("Choose a rank", $adminranks, 0);
		}
		$player->sendForm($form);
	}
	public function rankSetTempForm(Player $player):void{
	  $list = [];
    foreach($this->plugin->getServer()->getOnlinePlayers() as $p){
      $list[] = $p->getName();
    }
    $this->targetPlayer[$player->getName()] = $list;
		$form=new CustomForm(function(Player $player, $data=null):void{
			switch($data[1]){
				case "exit":
				$this->playerListForm($player);
				break;
				case "elite3d":
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Elite";
				$days=3;
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					Utils::giveTemporaryRank($target, "elite3d");
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank." for ".$days." days.");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank." for ".$days." days.");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("temprankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					$message=str_replace("{days}", $days, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case "elite7d":
				$target=$this->targetPlayer[$player->getName()][$data[0]];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Elite";
				$days=7;
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					Utils::giveTemporaryRank($target, "elite7d");
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank." for ".$days." days.");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank." for ".$days." days.");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("temprankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					$message=str_replace("{days}", $days, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case "elite14d":
				$target=$this->targetPlayer[$player->getName()];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Elite";
				$days=14;
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					Utils::giveTemporaryRank($target, "elite14d");
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank." for ".$days." days.");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank." for ".$days." days.");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("temprankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					$message=str_replace("{days}", $days, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case "elite30d":
				$target=$this->targetPlayer[$player->getName()];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Elite";
				$days=30;
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					Utils::giveTemporaryRank($target, "elite30d");
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank." for ".$days." days.");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank." for ".$days." days.");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("temprankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					$message=str_replace("{days}", $days, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case "premium3d":
				$target=$this->targetPlayer[$player->getName()];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Premium";
				$days=3;
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					Utils::giveTemporaryRank($target, "premium3d");
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank." for ".$days." days.");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank." for ".$days." days.");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("temprankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					$message=str_replace("{days}", $days, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case "premium7d":
				$target=$this->targetPlayer[$player->getName()];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Premium";
				$days=7;
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					Utils::giveTemporaryRank($target, "premium7d");
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank." for ".$days." days.");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank." for ".$days." days.");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("temprankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					$message=str_replace("{days}", $days, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case "premium14d":
				$target=$this->targetPlayer[$player->getName()];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Premium";
				$days=14;
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					Utils::giveTemporaryRank($target, "premium14d");
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank." for ".$days." days.");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank." for ".$days." days.");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("temprankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					$message=str_replace("{days}", $days, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
				case "premium30d":
				$target=$this->targetPlayer[$player->getName()];
				$targetpl=$this->plugin->getServer()->getPlayerExact($target);
				$rank=$this->plugin->getDatabaseHandler()->getRank($target);
				$newrank="Premium";
				$days=30;
				if($rank==$newrank){
					$player->sendMessage("§cThis player has already been assigned ".$newrank.".");
				}else{
					Utils::giveTemporaryRank($target, "premium30d");
					if($targetpl instanceof Player) $targetpl->sendMessage("§aYour rank was updated to ".$newrank." for ".$days." days.");
					$player->sendMessage("§aYou updated ".$target."'s rank to ".$newrank." for ".$days." days.");
					$message=$this->plugin->getStaffUtils()->sendStaffNoti("temprankchange");
					$message=str_replace("{name}", $player->getName(), $message);
					$message=str_replace("{target}", $target, $message);
					$message=str_replace("{oldrank}", $rank, $message);
					$message=str_replace("{newrank}", $newrank, $message);
					$message=str_replace("{days}", $days, $message);
					foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
						if($online->hasPermission("pc.staff.notifications")){
							$online->sendMessage($message);
						}
					}
				}
				break;
			}
			unset($this->targetPlayer[$player->getName()][$data[0]]);
		});
		$ranks = ["Elite 3D", "Elite.7D", "Elite14D", "Elite 30D"];
		$form->setTitle("§l§cTemp Rank");
		$form->addDropdown("Choose a rank", $ranks, 0);
		$form->addButton("Elite 3D", -1, "", 0);
		$form->addButton("Elite 7D", -1, "", 1);
		$form->addButton("Elite 14D", -1, "", 2);
		$form->addButton("Elite 30D", -1, "", 3);
		$form->addButton("Premium 3D", -1, "", 4);
		$form->addButton("Premium 7D", -1, "", 5);
		$form->addButton("Premium 14D", -1, "", 6);
		$form->addButton("Premium 30D", -1, "", 7);
		$form->addButton("« Back", -1, "", "exit");
		$player->sendForm($form);
	}
	public function rankInfoForm(Player $player, string $rank):void{
		$this->rank=$rank;
		$form=new SimpleForm(function (Player $player, $data=null):void{
			if($data===null) return;
				switch($data){
				case "exit":
				$this->rankListForm($player);
				break;
				case 0:
				$this->targetPlayer[$player->getName()]=$data;
				$target=$this->targetPlayer[$player->getName()];
				$this->rankForm($player);
				break;
			}
		});
		$form->setTitle("§l§cPlayers With ".$this->rank." Rank");
		$query=$this->plugin->main->query("SELECT * FROM rank ORDER BY rank;");
		while($result=$query->fetchArray(SQLITE3_ASSOC)){
			$target=$result['player'];
			$rank=$this->plugin->getDatabaseHandler()->getRank($target);
			if($rank==$this->rank) $form->addButton($target, -1, "", $target);
		}
		$form->addButton("« Back", -1, "", "exit");
		$player->sendForm($form);
	}
}