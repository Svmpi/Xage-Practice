<?php

declare(strict_types=1);

namespace Zinkil\pc\tasks;

use pocketmine\scheduler\Task;
use Zinkil\pc\Core;
use Zinkil\pc\CPlayer;
use Zinkil\pc\Utils;
use Zinkil\pc\handlers\ClickHandler;

class NameTagTask extends Task{
	
	public function __construct(Core $plugin){
		$this->plugin=$plugin;
	}
	public function onRun(int $tick):void{
		foreach($this->plugin->getServer()->getOnlinePlayers() as $player){
			$rank=$player->getRank();
			$ping=round($player->getPing(), 1);
			$health=round($player->getHealth(), 1);
			$os=$this->plugin->getPlayerOs($player);
			$ctrl=$this->plugin->getPlayerControls($player);
			$cps=$this->plugin->getClickHandler()->getCps($player);
			$kills=$this->plugin->getDatabaseHandler()->getKills($player);
			if($this->plugin->getDuelHandler()->getDuel($player)===null and $this->plugin->getDuelHandler()->getPartyDuel($player)===null){
			  if($player->isTagged()){
				$format=Utils::getNameTagTaggedFormat($rank);
				//$format=str_replace("{name}", Utils::getPlayerDisplayName($player), $format);
				$format = str_replace([
				'{name}',
				'{ping}',
				'{cps}'
				],
				[
				$player->getDisplayName(),
				$ping,
				$cps,
				], $format);
			  } else {
				$format=Utils::getNameTagFormat($rank);
				//$format=str_replace("{name}", Utils::getPlayerDisplayName($player), $format);
				$format = str_replace([
				'{name}',
				'{os}',
				'{ctrl}',
				],
				[
				$player->getDisplayName(),
				$os,
				$ctrl
				], $format);
			  }
				//$format=str_replace("{ping}", $ping, $format);
				//$format=str_replace("{hp}", $health, $format);
				//$format=str_replace("{os}", $os, $format);
				//$format=str_replace("{cps}", $cps, $format);
				//$format=str_replace("{kills}", $kills, $format);
				if(!$player->isDisguised()){
					if(!$player->isVanished()){
						$player->setNameTag($format);
					}else{
						$player->setNameTag("§7(V) ".$format);
					}
				}
			}
		}
    }
}